ZAILNS PORTFOLIO
=================

1. Загрузите index.html в репозиторий GitHub.
2. В Settings → Pages выберите Deploy from a branch.
3. Выберите ветку main и папку / (root).
4. Сохраните. GitHub выдаст адрес вида:
   https://ВАШНИК.github.io/ИМЯ-РЕПОЗИТОРИЯ/

Позже можно заменить блок PHOTO WILL BE ADDED на фотографию и
заменить WORK 02 / WORK 03 на реальные работы.

Сайт уже содержит SEO-заголовок и описание для поисковых систем.
